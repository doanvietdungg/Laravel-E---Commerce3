<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Thankyou extends Component
{
    public function render()
    {
        return view('livewire.thankyou')->layout('layouts.base');
    }
}
