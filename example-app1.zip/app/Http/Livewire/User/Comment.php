<?php

namespace App\Http\Livewire\User;

use Livewire\Component;

class Comment extends Component
{
    public function render()
    {
        return view('livewire.user.comment');
    }
}
