<?php

namespace App\Http\Livewire;

use Livewire\Component;

class ContacComponent extends Component
{
    public function render()
    {
        return view('livewire.contac-component')->layout('layouts.base');
    }
}
