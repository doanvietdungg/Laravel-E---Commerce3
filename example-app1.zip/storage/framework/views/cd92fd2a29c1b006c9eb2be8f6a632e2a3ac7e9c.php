<div class="container">
    <div class="row">
        <div class="col-md-12">
         <div class="panel panel-default">
             <?php if(session()->has('message')): ?>
             <div class="alert alert-success" role="alert" ><?php echo e(Session::get('message')); ?></div>

             <?php endif; ?>
             <div class="panel-heading">
              <h2> All Orders</h2>

             </div>

             <div class="panel-body">
                 <table class="table table-striped">
                     <thead>
                         <tr>
                            <th>Order ID</th>
                            <th>SubTotal</th>
                            <th>discount</th>
                            <th>Tax</th>
                            <th>Total</th>
                            <th>First name</th>
                            <th>Last name</th>
                            <th>Mobile</th>
                            <th>Email</th>
                            <th>Zip code</th>
                            <th>status</th>
                            <th>Date</th>
                            <th>Action</th>
                         </tr>
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                               <td><?php echo e($item->id); ?></td>
                               <td><?php echo e($item->subtotal); ?></td>
                               <td><?php echo e($item->discount); ?></td>
                               <td><?php echo e($item->tax); ?></td>

                               <td><?php echo e($item->total); ?></td>
                               <td><?php echo e($item->first_name); ?></td>
                               <td><?php echo e($item->last_name); ?></td>
                               <td><?php echo e($item->mobile); ?></td>
                               <td><?php echo e($item->email); ?></td>
                               <td><?php echo e($item->zip_code); ?></td>
                               <td><?php echo e($item->status); ?></td>
                               <td><?php echo e($item->created_at); ?></td>

                                <td ><a href="/user/AllOrder/<?php echo e($item->id); ?>"  class="btn btn-success">Detail Order</a></td>
                                <td> <button type="button" onclick="confirm('Are you sure') || event.stopImmediatePropagation()"    class="btn btn-danger" data-toggle="modal" data-target="#exampleModal"  wire:click=delete(<?php echo e($item->id); ?>)>
                                    Delete
                                  </button></td>
                            </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                 </table>

            </div>
                 <?php echo e($order->links()); ?>

             </div>
         </div>
        </div>
    </div>
</div>
<?php $__env->startSection('title'); ?>
Orders
<?php $__env->stopSection(); ?>
<?php /**PATH C:\Users\Dung\OneDrive\Máy tính\example-app1\resources\views/livewire/user/order-component.blade.php ENDPATH**/ ?>