
						<div class="wrap-search center-section">
							<div class="wrap-search-form">
								<form action="/Search" id="form-search-top" name="form-search-top">
									<input type="text" name="search" value=" <?php echo e($search); ?>" placeholder="Search here...">
									<button form="form-search-top" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
									<div class="wrap-list-cate">
										<input type="hidden" name="product_cate" value="<?php echo e($product_cate); ?>" id="product-cate">
                                        <input type="hidden" name="product_cate_id" value="<?php echo e($product_cate_id); ?>" id="product-cate">
										<a href="#" class="link-control"><?php echo e(str_split($product_cate,12)[0]); ?></a>
										<ul class="list-cate">
                                            <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                           <a href="/Product_Category/<?php echo e($item->slug); ?>" data-id="<?php echo e($item->id); ?>"> <li class="level-0"> <?php echo e($item->name); ?> </li></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


										</ul>
									</div>
								</form>
							</div>
						</div>
<?php /**PATH C:\Users\Dung\OneDrive\Máy tính\example-app1\resources\views/livewire/header-component.blade.php ENDPATH**/ ?>