<?php echo e($slot); ?>

<?php /**PATH C:\Users\Dung\OneDrive\Máy tính\example-app1\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>